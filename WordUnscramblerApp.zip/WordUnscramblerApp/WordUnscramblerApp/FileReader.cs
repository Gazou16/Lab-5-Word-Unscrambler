﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WordUnscramblerApp;

namespace WordUnscrambler
{
    class FileReader
    {
        public string[] Read(string filename)
        {
            try
            {
                // Read all lines from the file
                string[] lines = File.ReadAllLines(filename);

                // You may want to perform additional processing based on your file format
                // For example, if each line is a word, you might want to split each line into individual words
                List<string> words = new List<string>();
                foreach (string line in lines)
                {
                    words.AddRange(line.Split(','));
                }

                return words.ToArray();
            }
            catch (Exception ex)
            {
                // Handle file reading errors
                Console.WriteLine($"Error reading file: {ex.Message}");
                return new string[0]; // Return an empty array in case of an error
            }
        }
    }
}
