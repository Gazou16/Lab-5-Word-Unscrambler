﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Globalization;
using WordUnscramblerApp;

namespace WordUnscrambler
{
    class Program
    {
        private static readonly FileReader _fileReader = new FileReader();
        private static readonly WordMatcher _wordMatcher = new WordMatcher();
        private static string option;

        static void Main(string[] args)
        {


            for (int i = 0; i < 1;)
            {
                Console.WriteLine(lang.LanguagePrompt);
                String language = Console.ReadLine();
                switch (language.ToUpper())
                {
                    case "F":
                        Console.WriteLine(lang.French);
                        i++;
                        break;
                    case "E":
                        Console.WriteLine(lang.English);
                        i++;
                        break;
                    default:
                        Console.WriteLine(lang.OptionNotRecognized);
                        break;
                }
            }


            try
            {
                for (int i = 0; i < 1;)
                {
                    Console.WriteLine(lang.EnterScrambledWordsPrompt);
                    String option = Console.ReadLine() ?? throw new Exception("String is empty");

                    switch (option.ToUpper())
                    {
                        case "F":
                            Console.WriteLine(lang.FilePathPrompt);
                            ExecuteScrambledWordsInFileScenario();
                            i++;
                            break;
                        case "M":
                            Console.WriteLine(lang.ManualEntryPrompt);
                            ExecuteScrambledWordsManualEntryScenario();
                            i++;
                            break;
                        default:
                            Console.WriteLine(lang.OptionNotRecognized);
                            break;
                    }
                }
            }



            catch (Exception ex)
            {
                Console.WriteLine(lang.ProgramTerminationMessage + ex.Message);
            }

        }

        private static void ExecuteScrambledWordsInFileScenario()
        {
            var filename = Console.ReadLine();
            string[] scrambledWords = _fileReader.Read(filename);
            DisplayMatchedUnscrambledWords(scrambledWords);
        }

        private static void ExecuteScrambledWordsManualEntryScenario()
        {
            string scrambledWords = Console.ReadLine();
            string[] scrambledInput = scrambledWords.Split(',');

            for (int i = 0; i < scrambledInput.Length; i++)
            {
                scrambledInput[i] = scrambledInput[i].Trim();
                Console.WriteLine(scrambledInput[i]);
            }

            Console.WriteLine(lang.ManualEntryPrompt);

            string unscrambledWords = Console.ReadLine();
            string[] unscrambledInput = unscrambledWords.Split(',');

            for (int i = 0; i < unscrambledInput.Length; i++)
            {
                unscrambledInput[i] = unscrambledInput[i].Trim();
                Console.WriteLine(unscrambledInput[i]);
            }


            DisplayMatchedWordsManualEntry(scrambledInput, unscrambledInput);

        }

        private static void DisplayMatchedWordsManualEntry(string[] scrambledInput, string[] unscrambledInput)
        {
            List<MatchedWord> matchedWords = _wordMatcher.Match(scrambledInput, unscrambledInput);

            foreach (MatchedWord matchedWord in matchedWords)
            {
                Console.WriteLine($"Two Words Matched, Scrambled: {matchedWord.ScrambledWord}, " +
                    $"And Matched Word: {matchedWord.Word}");
            }

        }


        private static void DisplayMatchedUnscrambledWords(string[] scrambledWords)
        {
            //read the list of words from the system file. 
            string[] wordList = _fileReader.Read("wordlist.txt");

            //call a word matcher method to get a list of structs of matched words.
            List<MatchedWord> matchedWords = _wordMatcher.Match(scrambledWords, wordList);


            foreach (MatchedWord matchedWord in matchedWords)
            {
                Console.WriteLine(matchedWord.ToString());
            }
        }
    }
}


