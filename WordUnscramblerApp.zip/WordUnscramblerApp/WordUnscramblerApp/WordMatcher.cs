﻿using System;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WordUnscrambler;

namespace WordUnscramblerApp
{
    class WordMatcher
    {
        public List<MatchedWord> Match(string[] scrambledWords, string[] wordList)
        {
            List<MatchedWord> matchedWords = new List<MatchedWord>();

            foreach (string scrambledWord in scrambledWords)
            {

                foreach (string word in wordList)
                {

                    if (string.Equals(scrambledWord, word, StringComparison.OrdinalIgnoreCase))
                    {

                        matchedWords.Add(BuildMatchedWord(scrambledWord, word));

                    }

                }

            }

            return matchedWords;

        }

        MatchedWord BuildMatchedWord(string scrambledWord, string word)
        {

            return new MatchedWord
            {

                ScrambledWord = scrambledWord,
                Word = word

            };

        }
    }

}

